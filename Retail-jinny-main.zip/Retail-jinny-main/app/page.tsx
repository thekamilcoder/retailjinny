"use client";

import React, { useState } from "react";
import { Navbar } from "@/components/navbar";
import { Hero } from "@/components/hero";
import { Services } from "@/components/services";
import { Workflow } from "@/components/workflow";
import { Capability } from "@/components/capability";
import { WhyChooseUs } from "@/components/why-choose-us";
import { Footer } from "@/components/footer";
import { QuoteModal } from "@/components/quote-modal";

export default function Home() {
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false);
  const [selectedServiceForQuote, setSelectedServiceForQuote] = useState("");

  const handleOpenQuoteModal = (serviceName?: string) => {
    if (serviceName) {
      setSelectedServiceForQuote(serviceName);
    } else {
      setSelectedServiceForQuote("");
    }
    setIsQuoteModalOpen(true);
  };

  return (
    <div className="min-h-screen flex flex-col selection:bg-[#f1dbff] selection:text-[#2d0050]">
      {/* Dynamic Header */}
      <Navbar onOpenQuoteModal={handleOpenQuoteModal} />

      {/* Main Sections */}
      <main className="flex-grow">
        <Hero onOpenQuoteModal={handleOpenQuoteModal} />
        <Services onOpenQuoteModal={handleOpenQuoteModal} />
        <Workflow />
        <Capability onOpenQuoteModal={handleOpenQuoteModal} />
        <WhyChooseUs onOpenQuoteModal={handleOpenQuoteModal} />
      </main>

      {/* Footer */}
      <Footer onOpenQuoteModal={handleOpenQuoteModal} />

      {/* Interactive Global Quote Modal */}
      <QuoteModal
        isOpen={isQuoteModalOpen}
        onClose={() => setIsQuoteModalOpen(false)}
        defaultService={selectedServiceForQuote}
      />
    </div>
  );
}
