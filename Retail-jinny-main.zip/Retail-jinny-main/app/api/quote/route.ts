import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, email, phone, service, details, quantity } = body;

    if (!name || !email || !phone) {
      return NextResponse.json(
        { error: "Name, email, and phone are required fields." },
        { status: 400 }
      );
    }

    // Process/log quote request (in production, integrate with CRM, Email SDK, or Database)
    console.log("New RetailJinny Quote Request:", {
      name,
      email,
      phone,
      service: service || "General Quote",
      details,
      quantity,
      timestamp: new Date().toISOString(),
    });

    return NextResponse.json({
      success: true,
      message: "Quote request submitted successfully. Our team will contact you shortly.",
    });
  } catch (error) {
    console.error("Quote API Error:", error);
    return NextResponse.json(
      { error: "Internal server error. Please try again later." },
      { status: 500 }
    );
  }
}
