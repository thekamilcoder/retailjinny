import type { Metadata } from "next";
import { Hanken_Grotesk, Work_Sans } from "next/font/google";
import "./globals.css";

const hankenGrotesk = Hanken_Grotesk({
  variable: "--font-hanken-grotesk",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  display: "swap",
});

const workSans = Work_Sans({
  variable: "--font-work-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "RetailJinny | Your One-Stop Marketing & Printing Partner",
  description:
    "RetailJinny offers 100+ marketing and printing services in India. From website design and mobile apps to custom printing, flex banners, and business branding.",
  keywords: [
    "Printing Services",
    "Marketing Agency",
    "Brochure Printing",
    "Visiting Cards",
    "Flex Banner",
    "Website Design",
    "App Development",
    "RetailJinny",
  ],
  openGraph: {
    title: "RetailJinny | Your One-Stop Marketing & Printing Partner",
    description:
      "100+ Services | 5,000+ Happy Clients | 15+ Years of Excellence. Premium marketing and printing solutions across India.",
    url: "https://retailjinny.com",
    siteName: "RetailJinny",
    images: [
      {
        url: "/logo.png",
        width: 512,
        height: 512,
        alt: "RetailJinny Logo",
      },
    ],
    locale: "en_IN",
    type: "website",
  },
  twitter: {
    card: "summary",
    title: "RetailJinny | Marketing & Printing Partner",
    description: "100+ marketing and printing services across India. Fast delivery, expert team.",
    images: ["/logo.png"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${hankenGrotesk.variable} ${workSans.variable} scroll-smooth h-full antialiased`}
    >
      <head>
        <link
          rel="stylesheet"
          href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap"
        />
      </head>
      <body className="min-h-full flex flex-col bg-[#f8f9fa] text-[#191c1d] font-sans">
        {children}
      </body>
    </html>
  );
}

