---
name: Pro-Service Clarity
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#44474c'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#74777d'
  outline-variant: '#c4c6cc'
  surface-tint: '#525f71'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#0f1c2c'
  on-primary-container: '#778598'
  inverse-primary: '#bac8dc'
  secondary: '#8234c6'
  on-secondary: '#ffffff'
  secondary-container: '#b86dfd'
  on-secondary-container: '#410070'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#251a00'
  on-tertiary-container: '#a67e00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e4f9'
  primary-fixed-dim: '#bac8dc'
  on-primary-fixed: '#0f1c2c'
  on-primary-fixed-variant: '#3a4859'
  secondary-fixed: '#f1dbff'
  secondary-fixed-dim: '#deb7ff'
  on-secondary-fixed: '#2d0050'
  on-secondary-fixed-variant: '#680eac'
  tertiary-fixed: '#ffdf9a'
  tertiary-fixed-dim: '#f8be00'
  on-tertiary-fixed: '#251a00'
  on-tertiary-fixed-variant: '#5a4300'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  headline-xl:
    fontFamily: Hanken Grotesk
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Work Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Work Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Work Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Work Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  headline-lg-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1200px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  section-gap: 80px
  card-padding: 24px
---

## Brand & Style

The design system is built on a foundation of professional reliability and creative versatility. It targets business owners and marketing professionals who require a dependable, "one-stop" partner for physical and digital assets. 

The visual style is **Corporate / Modern** with subtle **Neo-Brutalist** influences—specifically the use of clean borders and structured card layouts to organize a high volume of service offerings. The aesthetic is "Professional & Approachable," utilizing a bright, clean background to let the vibrant brand colors (Navy, Purple, Yellow, Green) serve as functional signifiers for different service categories.

The UI should evoke:
- **Efficiency:** Through clear information hierarchy and scannable lists.
- **Trust:** Via robust typography and a structured, grid-based layout.
- **Vibrancy:** Using the multi-color palette to represent a wide range of creative possibilities.

## Colors

The palette is derived directly from the brand logo, with specific functional roles assigned to each hue:
- **Primary (Navy Blue):** Used for primary text, navigation backgrounds, and heavy structural elements. It provides the "professional" anchor.
- **Secondary (Purple):** Used for core service highlights, "Our Studio" identifiers, and primary action accents.
- **Tertiary (Yellow):** Used for "CTA" buttons (like WhatsApp Chat), "Sale" or "New" badges, and urgent highlights. It ensures high visibility against the navy.
- **Quaternary (Green):** Specifically used for "Success" states, "Budget-Friendly" markers, and specific service categories like Stationery or Business Cards.

The background remains a crisp, off-white (`#F8F9FA`) to maintain a "printing paper" feel, ensuring that the colorful service chips and cards remain legible and distinct.

## Typography

This design system uses a pairing of **Hanken Grotesk** for headlines and **Work Sans** for body and labels. 

- **Hanken Grotesk** provides a sharp, contemporary edge that feels "designed" and high-end, suitable for a printing and marketing agency.
- **Work Sans** offers exceptional legibility at small sizes, which is critical for the "100+ Services" lists and technical specifications (e.g., price per pc, material types).

Headers should predominantly use the Primary Navy color. Sub-headers and "Section Tags" (e.g., OUR SERVICES) should use the Label-LG style with increased letter spacing and a colored border or background container to differentiate sections clearly.

## Layout & Spacing

The system follows a **12-column Fluid Grid** for desktop, transitioning to a **4-column grid** for mobile. 

- **Service Cards:** In the "What We Offer" section, cards should span 3 columns on desktop (4 per row) and 6 columns on tablet.
- **Capability Grid:** The "100+ Printing Services" section uses a tighter 2-column grid within its own container to present more information quickly.
- **Vertical Rhythm:** A strict 8px base unit is used. Section headers are separated by 80px to give the content "room to breathe," reflecting a high-end service aesthetic.
- **Visual Dividers:** Use dashed or solid light-grey lines to separate the "What," "How," and "Why" sections, mirroring the structural clarity of a professional brochure.

## Elevation & Depth

This design system avoids heavy, realistic shadows in favor of **Tonal Layers** and **Structured Outlines**:

- **Level 0 (Surface):** The main background (`#F8F9FA`).
- **Level 1 (Cards):** Service cards use a 1px solid border (`#D1D5DB`) with a very subtle, tight ambient shadow (4px blur, 5% opacity).
- **Interactive Depth:** On hover, cards should lift slightly using a 2px solid Navy bottom border to create a "tab" effect, rather than a heavy drop shadow.
- **The "Accent Strip":** Following the reference images, many cards feature a 4px color-coded bottom or side border (Purple, Yellow, or Green) to categorize the service without cluttering the UI with icons.

## Shapes

The shape language is **Rounded (0.5rem / 8px)**. This strikes a balance between the precision of a professional service and the friendliness of a marketing partner.

- **Standard Cards:** 8px corner radius.
- **Buttons:** 8px corner radius for a sturdy, reliable feel.
- **Service Chips:** Use a full "Pill" shape (999px radius) for the "Full Service Suite" tag cloud to distinguish them from actionable cards.
- **Icon Containers:** Circular or 8px rounded squares depending on the icon style.

## Components

### Buttons
- **Primary:** Navy Blue background, White text. High-contrast, for "Request Quote."
- **Secondary (WhatsApp):** Yellow background, Navy text. High visibility for instant communication.
- **Outline:** 1px Navy border, Navy text, for secondary actions like "View All Services."

### Service Cards
Cards must include a 4px accent border on the left or bottom. They should contain a clear Headline (Medium), a small Icon or Badge, and a "Starting at" price label in a bold weight to drive conversion.

### Chips & Tags
Used for the "Full Service Suite." These should have a 1px border colored according to the brand palette (e.g., a "Visiting Card" chip has a Green border) with a light tinted background of the same color (5-10% opacity).

### Input Fields
Clean, 1px bordered boxes with 8px rounding. Focus states should use a 2px Purple border.

### Step Indicators
For the "How It Works" section, use large, bold Navy numbers (Headline-LG) paired with a vertical dashed line to guide the user through the 1-2-3-4 process.