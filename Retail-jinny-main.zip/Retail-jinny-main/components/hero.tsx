"use client";

import React from "react";
import { motion } from "framer-motion";

interface HeroProps {
  onOpenQuoteModal: (service?: string) => void;
}

export function Hero({ onOpenQuoteModal }: HeroProps) {
  const openWhatsApp = () => {
    const phone = "919876543210";
    const text = encodeURIComponent("Hi RetailJinny team! I need assistance with marketing and printing services.");
    window.open(`https://wa.me/${phone}?text=${text}`, "_blank");
  };

  return (
    <section className="relative px-5 md:px-16 pt-32 pb-16 md:pt-40 md:pb-24 flex flex-col items-center text-center max-w-[1200px] mx-auto overflow-hidden">
      {/* Background ambient gradient glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[#deb7ff]/30 rounded-full blur-3xl -z-10 pointer-events-none" />

      {/* Pill Badge */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[#8234c6] text-[#8234c6] font-semibold text-xs md:text-sm mb-6 uppercase tracking-widest bg-white/80 backdrop-blur-sm"
      >
        <span className="w-2 h-2 rounded-full bg-[#8234c6] animate-pulse"></span>
        Premium Design &amp; Print Studio
      </motion.div>

      {/* Main Title */}
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="font-headline text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold text-[#000000] max-w-4xl mb-6 leading-tight"
      >
        Your One-Stop Solution for{" "}
        <span className="text-[#8234c6] relative inline-block">
          Marketing &amp; Printing
          <svg
            className="absolute left-0 bottom-[-6px] w-full h-3 text-[#f8be00]"
            viewBox="0 0 200 9"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M2 7.5C50 2.5 150 2.5 198 7.5"
              stroke="currentColor"
              strokeWidth="4"
              strokeLinecap="round"
            />
          </svg>
        </span>
      </motion.h1>

      {/* Description */}
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="text-base sm:text-lg md:text-xl text-[#44474c] max-w-2xl mb-10 leading-relaxed"
      >
        100+ Services | 5,000+ Happy Clients | 15+ Years of Excellence. We turn your creative ideas into high-quality physical and digital realities.
      </motion.p>

      {/* CTA Buttons */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto"
      >
        <button
          onClick={() => onOpenQuoteModal()}
          className="px-8 py-4 bg-[#000000] text-white rounded-xl font-semibold text-base hover:shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 group cursor-pointer"
        >
          Request Free Quote
          <span className="material-symbols-outlined group-hover:translate-x-1 transition-transform">
            arrow_forward
          </span>
        </button>
        <button
          onClick={openWhatsApp}
          className="px-8 py-4 bg-[#ffdf9a] text-[#251a00] rounded-xl font-semibold text-base hover:shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 border border-[#f8be00] cursor-pointer"
        >
          WhatsApp Chat
          <span className="material-symbols-outlined">rocket_launch</span>
        </button>
      </motion.div>

      {/* Trust & Stat Counter Bar */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-6 w-full pt-8 border-t border-[#c4c6cc]/40"
      >
        <div className="flex flex-col items-center">
          <span className="font-headline text-3xl md:text-4xl font-extrabold text-[#000000]">
            5,000+
          </span>
          <span className="text-xs uppercase tracking-wider font-semibold text-[#44474c]">
            Happy Clients
          </span>
        </div>
        <div className="flex flex-col items-center">
          <span className="font-headline text-3xl md:text-4xl font-extrabold text-[#000000]">
            100+
          </span>
          <span className="text-xs uppercase tracking-wider font-semibold text-[#44474c]">
            Services Suite
          </span>
        </div>
        <div className="flex flex-col items-center">
          <span className="font-headline text-3xl md:text-4xl font-extrabold text-[#000000]">
            15+
          </span>
          <span className="text-xs uppercase tracking-wider font-semibold text-[#44474c]">
            Years Experience
          </span>
        </div>
        <div className="flex flex-col items-center">
          <span className="font-headline text-3xl md:text-4xl font-extrabold text-[#000000]">
            Pan-India
          </span>
          <span className="text-xs uppercase tracking-wider font-semibold text-[#44474c]">
            Express Delivery
          </span>
        </div>
      </motion.div>
    </section>
  );
}
