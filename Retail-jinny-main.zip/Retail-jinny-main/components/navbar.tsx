"use client";

import React, { useState, useEffect } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";

interface NavbarProps {
  onOpenQuoteModal: (service?: string) => void;
}

export function Navbar({ onOpenQuoteModal }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const openWhatsApp = () => {
    const phone = "919876543210";
    const text = encodeURIComponent("Hello RetailJinny! I'd like to discuss a marketing/printing project.");
    window.open(`https://wa.me/${phone}?text=${text}`, "_blank");
  };

  return (
    <>
      <header
        id="main-nav"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out flex justify-between items-center px-6 md:px-12 py-3 w-full bg-[#f8f9fa] ${
          isScrolled ? "nav-scrolled py-2" : ""
        }`}
      >
        {/* Brand Logo & Title */}
        <a href="#" className="flex items-center gap-3 group">
          <div className="relative w-10 h-10 md:w-12 md:h-12">
            <Image
              src="/logo.png"
              alt="RetailJinny Logo"
              fill
              style={{ objectFit: "contain" }}
              priority
            />
          </div>
          <span className="font-extrabold text-xl md:text-2xl tracking-tight text-[#000000] hidden sm:block font-headline">
            RetailJinny
          </span>
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-8">
          <a
            href="#services"
            className="text-sm font-semibold text-[#44474c] hover:text-[#000000] transition-colors"
          >
            Services
          </a>
          <a
            href="#workflow"
            className="text-sm font-semibold text-[#44474c] hover:text-[#000000] transition-colors"
          >
            Workflow
          </a>
          <a
            href="#capability"
            className="text-sm font-semibold text-[#44474c] hover:text-[#000000] transition-colors"
          >
            Printing
          </a>
          <a
            href="#about"
            className="text-sm font-semibold text-[#44474c] hover:text-[#000000] transition-colors"
          >
            About
          </a>
        </nav>

        {/* Action Buttons */}
        <div className="flex items-center gap-3">
          <button
            onClick={openWhatsApp}
            className="p-2 rounded-full text-[#44474c] hover:text-[#000000] hover:bg-black/5 transition-colors"
            title="Chat on WhatsApp"
            aria-label="WhatsApp Chat"
          >
            <span className="material-symbols-outlined">chat</span>
          </button>
          <button
            onClick={() => onOpenQuoteModal()}
            className="hidden sm:block px-6 py-2.5 rounded-full bg-[#000000] text-white text-sm font-semibold hover:scale-105 active:scale-95 transition-all shadow-sm"
          >
            Request Quote
          </button>
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="sm:hidden p-2 rounded-full border border-[#74777d] text-[#191c1d]"
            aria-label="Toggle Menu"
          >
            <span className="material-symbols-outlined">
              {isMobileMenuOpen ? "close" : "menu"}
            </span>
          </button>
        </div>
      </header>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-x-0 top-16 z-40 bg-white border-b border-[#c4c6cc] p-6 shadow-xl md:hidden"
          >
            <div className="flex flex-col gap-4 font-medium text-base">
              <a
                href="#services"
                onClick={() => setIsMobileMenuOpen(false)}
                className="py-2 border-b border-gray-100 text-[#191c1d]"
              >
                Services
              </a>
              <a
                href="#workflow"
                onClick={() => setIsMobileMenuOpen(false)}
                className="py-2 border-b border-gray-100 text-[#191c1d]"
              >
                Workflow
              </a>
              <a
                href="#capability"
                onClick={() => setIsMobileMenuOpen(false)}
                className="py-2 border-b border-gray-100 text-[#191c1d]"
              >
                100+ Printing Capabilities
              </a>
              <a
                href="#about"
                onClick={() => setIsMobileMenuOpen(false)}
                className="py-2 border-b border-gray-100 text-[#191c1d]"
              >
                About Us
              </a>
              <div className="pt-2 flex flex-col gap-3">
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onOpenQuoteModal();
                  }}
                  className="w-full py-3 bg-[#000000] text-white rounded-xl font-semibold text-center"
                >
                  Request Free Quote
                </button>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    openWhatsApp();
                  }}
                  className="w-full py-3 bg-[#ffdf9a] text-[#251a00] rounded-xl font-semibold text-center flex items-center justify-center gap-2"
                >
                  <span className="material-symbols-outlined">rocket_launch</span>
                  WhatsApp Quick Chat
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
