"use client";

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface ServicesProps {
  onOpenQuoteModal: (service?: string) => void;
}

interface ServiceItem {
  id: string;
  title: string;
  category: string;
  description: string;
  icon: string;
  borderClass: string;
  iconBg: string;
  iconColor: string;
  textColor: string;
  details: string[];
  startingPrice: string;
}

const SERVICES_DATA: ServiceItem[] = [
  {
    id: "web-design",
    title: "Website Design",
    category: "Digital Growth",
    description: "Responsive, modern, and high-converting websites built to represent your brand digitally.",
    icon: "language",
    borderClass: "service-card-border-purple",
    iconBg: "bg-[#8234c6]/10",
    iconColor: "text-[#8234c6]",
    textColor: "text-[#8234c6]",
    startingPrice: "Starts @ ₹ 999",
    details: [
      "Custom responsive UI/UX design",
      "SEO optimized architecture & fast page load",
      "E-commerce & WhatsApp order integration",
      "Free 1-year domain & SSL certificate",
    ],
  },
  {
    id: "app-dev",
    title: "App Development",
    category: "Mobile Solutions",
    description: "Native and hybrid mobile applications focusing on user experience, speed, and performance.",
    icon: "smartphone",
    borderClass: "service-card-border-yellow",
    iconBg: "bg-[#ffdf9a]/40",
    iconColor: "text-[#5a4300]",
    textColor: "text-[#5a4300]",
    startingPrice: "Starts @ ₹ 1,999",
    details: [
      "iOS & Android cross-platform apps",
      "Push notifications & live tracking",
      "Secure payment gateway integration",
      "Play Store & App Store deployment",
    ],
  },
  {
    id: "banner-flex",
    title: "Banner & Flex",
    category: "Large Format Print",
    description: "High-visibility large format printing for events, storefronts, trade shows, and outdoor advertising.",
    icon: "imagesmode",
    borderClass: "service-card-border-green",
    iconBg: "bg-green-100",
    iconColor: "text-green-600",
    textColor: "text-green-700",
    startingPrice: "Starts @ ₹ 12/sq.ft",
    details: [
      "Star flex, backlit flex & vinyl printing",
      "Weather-proof UV resistant inks",
      "Hemming & eyelet grommets included",
      "Same-day dispatch for urgent events",
    ],
  },
  {
    id: "customized-products",
    title: "Customized Products",
    category: "Corporate Gifting",
    description: "Mugs, T-shirts, bottles, and corporate gifting items branded with your unique logo.",
    icon: "inventory_2",
    borderClass: "service-card-border-purple",
    iconBg: "bg-[#8234c6]/10",
    iconColor: "text-[#8234c6]",
    textColor: "text-[#8234c6]",
    startingPrice: "Starts @ ₹ 150/unit",
    details: [
      "Custom embroidered & screen-printed T-shirts",
      "Ceramic mugs & stainless steel flasks",
      "Customized gift combos & welcome kits",
      "No minimum order quantity required",
    ],
  },
  {
    id: "marketing-team",
    title: "Marketing Team",
    category: "Dedicated Talent",
    description: "Hire our experts on-demand to handle your digital, social media, and offline campaigns.",
    icon: "groups",
    borderClass: "service-card-border-yellow",
    iconBg: "bg-[#ffdf9a]/40",
    iconColor: "text-[#5a4300]",
    textColor: "text-[#5a4300]",
    startingPrice: "Starts @ ₹ 9,999/mo",
    details: [
      "Dedicated Social Media Manager & Graphic Designer",
      "Google Ads & Meta Ads campaign management",
      "Content creation, copy & video reels",
      "Weekly performance reports & strategy calls",
    ],
  },
  {
    id: "printing-services",
    title: "Printing Services",
    category: "Offset & Digital",
    description: "Bulk offset, digital, and screen printing with professional finishing and packaging.",
    icon: "print",
    borderClass: "service-card-border-green",
    iconBg: "bg-green-100",
    iconColor: "text-green-600",
    textColor: "text-green-700",
    startingPrice: "Starts @ ₹ 1.50/pc",
    details: [
      "Visiting cards, letterheads & envelopes",
      "Brochures, flyers & product catalogs",
      "Die-cut stickers & label printing",
      "Lamination, foil stamping & spot UV finishing",
    ],
  },
];

export function Services({ onOpenQuoteModal }: ServicesProps) {
  const [activeServiceModal, setActiveServiceModal] = useState<ServiceItem | null>(null);

  return (
    <section id="services" className="px-5 md:px-16 py-20 bg-[#f3f4f5]">
      <div className="max-w-[1200px] mx-auto">
        {/* Section Header */}
        <div className="flex flex-col items-center mb-16 text-center">
          <div className="w-12 h-1 bg-[#8234c6] mb-4 rounded-full"></div>
          <span className="text-xs uppercase tracking-widest font-semibold text-[#8234c6] mb-2">
            Tailored Excellence
          </span>
          <h2 className="font-headline text-3xl md:text-5xl font-bold text-[#000000] mb-4">
            What We Offer
          </h2>
          <p className="text-[#44474c] text-base md:text-lg max-w-xl">
            Customized solutions designed for your brand&apos;s visibility, growth, and long-term impact.
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {SERVICES_DATA.map((item, idx) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className={`group bg-white p-6 md:p-8 rounded-xl border border-[#c4c6cc]/70 ${item.borderClass} neo-shadow transition-all duration-300 hover:-translate-y-1.5 flex flex-col justify-between`}
            >
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div
                    className={`w-12 h-12 rounded-xl ${item.iconBg} flex items-center justify-center`}
                  >
                    <span className={`material-symbols-outlined ${item.iconColor} text-2xl`}>
                      {item.icon}
                    </span>
                  </div>
                  <span className="text-xs font-bold px-3 py-1 rounded-full bg-[#f8f9fa] border border-[#c4c6cc]/50 text-[#44474c]">
                    {item.startingPrice}
                  </span>
                </div>
                <h3 className="font-headline text-2xl font-bold text-[#000000] mb-3">
                  {item.title}
                </h3>
                <p className="text-[#44474c] text-sm md:text-base mb-6 leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="pt-4 border-t border-gray-100 flex items-center justify-between">
                <button
                  onClick={() => setActiveServiceModal(item)}
                  className={`font-semibold text-sm ${item.textColor} inline-flex items-center gap-1 group-hover:gap-2 transition-all cursor-pointer`}
                >
                  Explore Service Details
                  <span className="material-symbols-outlined text-sm">chevron_right</span>
                </button>
                <button
                  onClick={() => onOpenQuoteModal(item.title)}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-[#000000] text-white hover:bg-slate-800 transition-colors"
                >
                  Quote
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Service Detail Modal */}
      <AnimatePresence>
        {activeServiceModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveServiceModal(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative z-10 w-full max-w-lg bg-white rounded-2xl p-6 md:p-8 shadow-2xl border border-[#c4c6cc]"
            >
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-12 h-12 rounded-xl ${activeServiceModal.iconBg} flex items-center justify-center`}
                  >
                    <span className={`material-symbols-outlined ${activeServiceModal.iconColor} text-2xl`}>
                      {activeServiceModal.icon}
                    </span>
                  </div>
                  <div>
                    <span className="text-xs uppercase tracking-wider font-semibold text-[#8234c6]">
                      {activeServiceModal.category}
                    </span>
                    <h3 className="text-2xl font-bold font-headline text-[#000000]">
                      {activeServiceModal.title}
                    </h3>
                  </div>
                </div>
                <button
                  onClick={() => setActiveServiceModal(null)}
                  className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-600 hover:bg-gray-200"
                >
                  <span className="material-symbols-outlined text-sm">close</span>
                </button>
              </div>

              <p className="text-[#44474c] mb-6 text-sm leading-relaxed">
                {activeServiceModal.description}
              </p>

              <div className="mb-6 bg-[#f8f9fa] p-4 rounded-xl border border-[#e7e8e9]">
                <h4 className="font-semibold text-sm text-[#000000] mb-3">What&apos;s Included:</h4>
                <ul className="space-y-2 text-xs md:text-sm text-[#44474c]">
                  {activeServiceModal.details.map((feat, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <span className="material-symbols-outlined text-[#8234c6] text-base">
                        check_circle
                      </span>
                      {feat}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="text-sm font-bold text-[#000000]">
                  {activeServiceModal.startingPrice}
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={() => setActiveServiceModal(null)}
                    className="px-4 py-2 border border-gray-300 rounded-xl text-sm font-semibold hover:bg-gray-50"
                  >
                    Close
                  </button>
                  <button
                    onClick={() => {
                      const title = activeServiceModal.title;
                      setActiveServiceModal(null);
                      onOpenQuoteModal(title);
                    }}
                    className="px-6 py-2 bg-[#000000] text-white rounded-xl text-sm font-semibold hover:bg-slate-800"
                  >
                    Request Custom Quote
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
