"use client";

import React from "react";
import Image from "next/image";
import { motion } from "framer-motion";

export function Workflow() {
  const STEPS = [
    {
      num: "01",
      title: "Discussion",
      desc: "We gather your branding specs, dimensions, material choices, quantity requirements, and timeline goals.",
    },
    {
      num: "02",
      title: "Design",
      desc: "Digital layout, vector artwork creation, 3D product mockups, and print-ready creative support.",
    },
    {
      num: "03",
      title: "Production",
      desc: "Precision large-format print, visiting cards, apparel printing, labels, packaging, and signage manufacturing.",
    },
    {
      num: "04",
      title: "Delivery",
      desc: "Careful dispatch with optional 24-hour express delivery support to your door anywhere in India.",
    },
  ];

  return (
    <section id="workflow" className="px-5 md:px-16 py-20 bg-white">
      <div className="max-w-[1200px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left Column: Timeline Steps */}
          <div>
            <div className="inline-block px-4 py-1.5 rounded-full bg-[#f1dbff] text-[#410070] font-semibold text-xs uppercase tracking-widest mb-6">
              WORKFLOW
            </div>
            <h2 className="font-headline text-3xl md:text-5xl font-extrabold text-[#000000] mb-6">
              How RetailJinny Works
            </h2>
            <p className="text-base md:text-lg text-[#44474c] mb-12 max-w-lg leading-relaxed">
              We&apos;ve streamlined our production process to ensure every project is delivered on time, within budget, and to the highest industry standards.
            </p>

            <div className="space-y-8 relative">
              {/* Vertical Dashed Line */}
              <div className="absolute left-6 top-8 bottom-8 w-px dashed-line -z-10" />

              {STEPS.map((step, idx) => (
                <motion.div
                  key={step.num}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: idx * 0.1 }}
                  className="flex gap-6 items-start"
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#000000] text-white flex items-center justify-center font-headline font-bold text-lg shadow-md">
                    {step.num}
                  </div>
                  <div>
                    <h3 className="font-headline text-xl font-bold text-[#000000] mb-1">
                      {step.title}
                    </h3>
                    <p className="text-[#44474c] text-sm md:text-base leading-relaxed">
                      {step.desc}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Right Column: Visual Studio & Trust Badge */}
          <div className="relative mt-8 lg:mt-0">
            <div className="aspect-[4/3] bg-[#edeeef] rounded-3xl overflow-hidden neo-shadow border border-[#c4c6cc] relative">
              <Image
                src="/retail-jinny-workshop.jpeg"
                alt="RetailJinny Studio Workshop"
                fill
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 50vw"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
            </div>

            {/* Floating Trust Badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="absolute -bottom-8 -left-4 md:-left-8 bg-[#251a00] text-white px-6 md:px-8 py-5 md:py-6 rounded-2xl shadow-2xl border border-white/10"
            >
              <div className="flex items-center gap-4">
                <span className="material-symbols-outlined text-4xl text-[#f8be00]">
                  verified
                </span>
                <div>
                  <p className="font-headline text-2xl font-bold text-white">40% Savings</p>
                  <p className="text-xs text-white/80">On average overall marketing spend</p>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
