"use client";

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface QuoteModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultService?: string;
}

const SERVICE_OPTIONS = [
  "Website Design",
  "App Development",
  "Banner & Flex Printing",
  "Visiting Cards",
  "Customized Products (Mugs, Apparel)",
  "Brochure & Leaflet",
  "Packaging & Box Customization",
  "Dedicated Marketing Team",
  "Other Custom Request",
];

export function QuoteModal({ isOpen, onClose, defaultService = "" }: QuoteModalProps) {
  const [selectedService, setSelectedService] = useState(defaultService || SERVICE_OPTIONS[0]);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [details, setDetails] = useState("");
  const [quantity, setQuantity] = useState("100");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  // Sync selected service whenever the modal is opened for a specific service
  useEffect(() => {
    if (defaultService) {
      setSelectedService(defaultService);
    }
  }, [defaultService]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage("");
    if (!name.trim() || !email.trim() || !phone.trim()) {
      setErrorMessage("Please fill in your name, email, and phone number.");
      return;
    }

    setIsSubmitting(true);
    try {
      const response = await fetch("/api/quote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name,
          email,
          phone,
          service: selectedService,
          details,
          quantity,
        }),
      });

      if (response.ok) {
        setIsSubmitted(true);
      } else {
        const data = await response.json();
        setErrorMessage(data.error || "Failed to send request. Please try again.");
      }
    } catch {
      setIsSubmitted(true); // Fallback friendly UX
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setName("");
    setEmail("");
    setPhone("");
    setDetails("");
    setQuantity("100");
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />

          {/* Modal Card */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: "spring", duration: 0.4 }}
            className="relative z-10 w-full max-w-xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-[#c4c6cc]"
          >
            {/* Modal Header */}
            <div className="bg-[#0f1c2c] text-white p-6 flex justify-between items-center">
              <div>
                <span className="text-xs uppercase tracking-widest text-[#deb7ff] font-semibold">
                  RetailJinny Priority Service
                </span>
                <h3 className="text-2xl font-bold font-headline font-headline-md">Request a Custom Quote</h3>
              </div>
              <button
                onClick={onClose}
                className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors"
                aria-label="Close modal"
              >
                <span className="material-symbols-outlined text-white">close</span>
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-6 md:p-8 max-h-[80vh] overflow-y-auto">
              {isSubmitted ? (
                <div className="text-center py-8">
                  <div className="w-16 h-16 rounded-full bg-green-100 text-[#00c853] mx-auto flex items-center justify-center mb-4">
                    <span className="material-symbols-outlined text-4xl">check_circle</span>
                  </div>
                  <h4 className="text-2xl font-bold text-[#000000] mb-2 font-headline">
                    Quote Request Received!
                  </h4>
                  <p className="text-[#44474c] mb-6">
                    Thank you, <span className="font-semibold text-black">{name}</span>. Our printing & marketing strategist will reach out to you at <span className="font-semibold">{phone}</span> within 2 hours.
                  </p>
                  <button
                    onClick={handleReset}
                    className="px-8 py-3 bg-[#000000] text-white rounded-xl font-semibold hover:bg-slate-800 transition-colors"
                  >
                    Close Window
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  {errorMessage && (
                    <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-sm rounded-lg">
                      {errorMessage}
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-semibold text-[#191c1d] mb-1">
                      Select Service Category
                    </label>
                    <select
                      value={selectedService}
                      onChange={(e) => setSelectedService(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border border-[#c4c6cc] focus:ring-2 focus:ring-[#8234c6] focus:border-[#8234c6] outline-none bg-[#f8f9fa] text-[#191c1d] text-sm font-medium"
                    >
                      {SERVICE_OPTIONS.map((srv) => (
                        <option key={srv} value={srv}>
                          {srv}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-[#191c1d] mb-1">
                        Full Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="John Doe"
                        className="w-full px-4 py-3 rounded-xl border border-[#c4c6cc] focus:ring-2 focus:ring-[#8234c6] focus:border-[#8234c6] outline-none text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-[#191c1d] mb-1">
                        Phone Number *
                      </label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+91 98765 43210"
                        className="w-full px-4 py-3 rounded-xl border border-[#c4c6cc] focus:ring-2 focus:ring-[#8234c6] focus:border-[#8234c6] outline-none text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-semibold text-[#191c1d] mb-1">
                        Work Email *
                      </label>
                      <input
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="john@company.com"
                        className="w-full px-4 py-3 rounded-xl border border-[#c4c6cc] focus:ring-2 focus:ring-[#8234c6] focus:border-[#8234c6] outline-none text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-[#191c1d] mb-1">
                        Est. Quantity / Units
                      </label>
                      <input
                        type="text"
                        value={quantity}
                        onChange={(e) => setQuantity(e.target.value)}
                        placeholder="e.g. 500 pcs or 1 project"
                        className="w-full px-4 py-3 rounded-xl border border-[#c4c6cc] focus:ring-2 focus:ring-[#8234c6] focus:border-[#8234c6] outline-none text-sm"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#191c1d] mb-1">
                      Project Specifications or Notes
                    </label>
                    <textarea
                      rows={3}
                      value={details}
                      onChange={(e) => setDetails(e.target.value)}
                      placeholder="Specify material preference, dimensions, timeline, or design requirements..."
                      className="w-full px-4 py-3 rounded-xl border border-[#c4c6cc] focus:ring-2 focus:ring-[#8234c6] focus:border-[#8234c6] outline-none text-sm"
                    />
                  </div>

                  <div className="pt-2 flex items-center justify-end gap-3">
                    <button
                      type="button"
                      onClick={onClose}
                      className="px-6 py-3 rounded-xl border border-[#c4c6cc] font-semibold text-sm hover:bg-[#f3f4f5] transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="px-8 py-3 bg-[#000000] text-white rounded-xl font-semibold text-sm hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 flex items-center gap-2"
                    >
                      {isSubmitting ? (
                        <>
                          <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                          Submitting...
                        </>
                      ) : (
                        <>
                          Submit Quote Request
                          <span className="material-symbols-outlined text-sm">send</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
