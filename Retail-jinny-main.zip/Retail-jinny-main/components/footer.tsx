"use client";

import React from "react";
import Image from "next/image";

interface FooterProps {
  onOpenQuoteModal: (service?: string) => void;
}

export function Footer({ onOpenQuoteModal }: FooterProps) {
  const openWhatsApp = () => {
    const phone = "919876543210";
    const text = encodeURIComponent("Hello RetailJinny! I would like to get a brochure / contact card.");
    window.open(`https://wa.me/${phone}?text=${text}`, "_blank");
  };

  return (
    <footer className="bg-[#0f1c2c] text-[#778598] border-t border-white/10">
      <div className="max-w-[1200px] mx-auto px-5 md:px-16 py-16 md:py-20">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          {/* Brand Column */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="relative w-10 h-10">
                <Image
                  src="/logo.png"
                  alt="RetailJinny Logo"
                  fill
                  style={{ objectFit: "contain" }}
                />
              </div>
              <span className="font-headline text-2xl font-extrabold text-white">
                RetailJinny
              </span>
            </div>
            <p className="text-sm text-[#778598] max-w-sm mb-8 leading-relaxed">
              RetailJinny is your premier partner for all marketing and printing needs in India. We provide high-quality physical and digital growth solutions for businesses of all sizes.
            </p>
            <div className="flex gap-3">
              <a
                href="#"
                className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white hover:bg-[#8234c6] hover:border-[#8234c6] transition-colors"
                aria-label="Website"
              >
                <span className="material-symbols-outlined text-sm">public</span>
              </a>
              <button
                onClick={openWhatsApp}
                className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white hover:bg-[#8234c6] hover:border-[#8234c6] transition-colors cursor-pointer"
                aria-label="WhatsApp"
              >
                <span className="material-symbols-outlined text-sm">chat</span>
              </button>
              <button
                onClick={() => onOpenQuoteModal()}
                className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-white hover:bg-[#8234c6] hover:border-[#8234c6] transition-colors cursor-pointer"
                aria-label="Quote"
              >
                <span className="material-symbols-outlined text-sm">request_quote</span>
              </button>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-headline text-lg font-bold text-white mb-6">Quick Links</h4>
            <ul className="space-y-3 text-sm text-[#778598]">
              <li>
                <a href="#services" className="hover:text-white transition-colors">
                  Services Suite
                </a>
              </li>
              <li>
                <a href="#workflow" className="hover:text-white transition-colors">
                  Workflow &amp; Process
                </a>
              </li>
              <li>
                <a href="#capability" className="hover:text-white transition-colors">
                  100+ Capabilities
                </a>
              </li>
              <li>
                <a href="#about" className="hover:text-white transition-colors">
                  Why Choose Us
                </a>
              </li>
              <li>
                <button
                  onClick={() => onOpenQuoteModal()}
                  className="hover:text-white transition-colors text-left"
                >
                  Request a Quote
                </button>
              </li>
            </ul>
          </div>

          {/* Contact & QR Code */}
          <div>
            <h4 className="font-headline text-lg font-bold text-white mb-6">Contact Us</h4>
            <div className="space-y-3 text-sm text-[#778598]">
              <div className="flex items-center gap-3">
                <span className="material-symbols-outlined text-[#f8be00] text-lg">call</span>
                <span className="text-white">+91 98765 43210</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="material-symbols-outlined text-[#f8be00] text-lg">mail</span>
                <span className="text-white">hello@retailjinny.com</span>
              </div>

              <div
                onClick={openWhatsApp}
                className="mt-6 p-4 bg-white/5 rounded-xl border border-white/10 flex items-center gap-4 cursor-pointer hover:bg-white/10 transition-all group"
              >
                <div className="w-14 h-14 bg-white rounded-lg p-1.5 flex items-center justify-center flex-shrink-0">
                  <span className="material-symbols-outlined text-[#000000] text-3xl group-hover:scale-110 transition-transform">
                    qr_code_2
                  </span>
                </div>
                <p className="text-xs text-white/80 leading-tight">
                  Scan / Tap to get our contact card directly on WhatsApp
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-[#778598]">
          <p>© {new Date().getFullYear()} RetailJinny. All rights reserved.</p>
          <p>Made with ❤️ in India | Pan-India Express Delivery</p>
        </div>
      </div>
    </footer>
  );
}
