"use client";

import React, { useState, useMemo } from "react";
import { motion } from "framer-motion";

interface CapabilityProps {
  onOpenQuoteModal: (service?: string) => void;
}

interface CapabilityItem {
  id: string;
  name: string;
  category: "printing" | "branding" | "digital" | "gifting";
  desc: string;
  badge?: "HOT" | "NEW" | "POPULAR" | "ECO";
  price: string;
  icon: string;
  iconColor: string;
}

const ALL_CAPABILITIES: CapabilityItem[] = [
  {
    id: "brochure",
    name: "Brochure & Pamphlets",
    category: "printing",
    desc: "Bi-fold, tri-fold, multi-page booklet & custom die-cut",
    badge: "HOT",
    price: "Starts @ ₹ 2.50/pc",
    icon: "auto_stories",
    iconColor: "text-[#deb7ff]",
  },
  {
    id: "visiting-cards",
    name: "Visiting Cards",
    category: "printing",
    desc: "Matte, velvet, spot UV, gold foil, metallic & plastic",
    badge: "NEW",
    price: "Starts @ ₹ 1.50/card",
    icon: "contact_mail",
    iconColor: "text-green-400",
  },
  {
    id: "flex-banner",
    name: "Flex & Banner",
    category: "branding",
    desc: "Star flex, backlit flex, vinyl, mesh & hoardings",
    price: "Starts @ ₹ 12/sq.ft",
    icon: "campaign",
    iconColor: "text-yellow-400",
  },
  {
    id: "packaging-boxes",
    name: "Packaging & Boxes",
    category: "gifting",
    desc: "Rigid boxes, corrugated shipping boxes, pouches",
    badge: "POPULAR",
    price: "Starts @ ₹ 5.00/pc",
    icon: "package_2",
    iconColor: "text-[#deb7ff]",
  },
  {
    id: "label-stickers",
    name: "Label & Stickers",
    category: "printing",
    desc: "Waterproof vinyl, clear transparent, paper stickers",
    price: "Starts @ ₹ 0.80/pc",
    icon: "loyalty",
    iconColor: "text-pink-400",
  },
  {
    id: "acrylic-boards",
    name: "Acrylic & LED Signage",
    category: "branding",
    desc: "3D neon letter boards, glow sign boards, acrylic cutouts",
    badge: "HOT",
    price: "Starts @ ₹ 150/sq.ft",
    icon: "lightbulb",
    iconColor: "text-yellow-300",
  },
  {
    id: "id-cards-lanyards",
    name: "ID Cards & Lanyards",
    category: "gifting",
    desc: "PVC smart cards, satin printed neck lanyards, holders",
    price: "Starts @ ₹ 15/set",
    icon: "badge",
    iconColor: "text-cyan-400",
  },
  {
    id: "standees-canopy",
    name: "Roll Up Standees",
    category: "branding",
    desc: "Aluminum roll-up standees, promo tables, event canopies",
    badge: "POPULAR",
    price: "Starts @ ₹ 750/unit",
    icon: "view_carousel",
    iconColor: "text-orange-400",
  },
];

const TAG_CLOUD = [
  "Digital Printing",
  "Offset Printing",
  "DTF Garments",
  "Label Stickers",
  "ID Cards",
  "Bill Books",
  "Sun Board",
  "Lanyards",
  "Eco Solvent",
  "UV Flatbed",
  "Canopy Tents",
  "Letterhead Pads",
  "Custom Envelopes",
  "Promotional Pens",
  "Custom Caps",
];

export function Capability({ onOpenQuoteModal }: CapabilityProps) {
  const [activeTab, setActiveTab] = useState<"all" | "printing" | "branding" | "digital" | "gifting">("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCapabilities = useMemo(() => {
    return ALL_CAPABILITIES.filter((cap) => {
      const matchesTab = activeTab === "all" || cap.category === activeTab;
      const matchesSearch =
        cap.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        cap.desc.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesTab && matchesSearch;
    });
  }, [activeTab, searchQuery]);

  return (
    <section id="capability" className="px-5 md:px-16 py-20 bg-[#0f1c2c] text-white">
      <div className="max-w-[1200px] mx-auto">
        {/* Section Header */}
        <div className="flex flex-col items-center mb-12 text-center">
          <div className="inline-block px-4 py-1.5 rounded-full border border-[#d6e4f9] text-[#d6e4f9] font-semibold text-xs uppercase tracking-widest mb-6">
            OUR CAPABILITY
          </div>
          <h2 className="font-headline text-3xl md:text-5xl font-extrabold text-white mb-6">
            100+ Printing &amp; Marketing Services
          </h2>
          <p className="text-[#bac8dc] text-base md:text-lg max-w-2xl leading-relaxed">
            From traditional business essentials to modern high-tech marketing assets, we deliver precision and quality for every scale.
          </p>
        </div>

        {/* Filter & Search Bar */}
        <div className="mb-10 flex flex-col md:flex-row items-center justify-between gap-4 bg-white/5 p-4 rounded-2xl border border-white/10">
          {/* Tabs */}
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: "all", label: "All Capabilities" },
              { id: "printing", label: "Offset & Digital" },
              { id: "branding", label: "Signage & Banners" },
              { id: "gifting", label: "Corporate Gifting" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                  activeTab === tab.id
                    ? "bg-[#8234c6] text-white shadow-lg"
                    : "bg-white/10 text-white/80 hover:bg-white/20"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Search Bar */}
          <div className="relative w-full md:w-72">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-white/60 text-sm">
              search
            </span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search capability..."
              className="w-full pl-9 pr-4 py-2 bg-white/10 border border-white/20 rounded-xl text-sm text-white placeholder-white/50 focus:outline-none focus:border-[#8234c6]"
            />
          </div>
        </div>

        {/* Capability Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredCapabilities.map((item, idx) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: idx * 0.05 }}
              className="bg-white/5 p-6 rounded-xl border border-white/10 hover:border-[#8234c6]/50 hover:bg-white/10 transition-all cursor-pointer group flex flex-col justify-between"
              onClick={() => onOpenQuoteModal(item.name)}
            >
              <div>
                <div className="flex justify-between items-start mb-6">
                  <span className={`material-symbols-outlined ${item.iconColor} text-3xl`}>
                    {item.icon}
                  </span>
                  {item.badge && (
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded text-white ${
                        item.badge === "HOT"
                          ? "bg-red-500"
                          : item.badge === "NEW"
                          ? "bg-green-500"
                          : "bg-[#8234c6]"
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </div>
                <h3 className="font-headline text-lg font-bold text-white mb-2 group-hover:text-[#deb7ff] transition-colors">
                  {item.name}
                </h3>
                <p className="text-xs text-white/70 mb-6 leading-relaxed">
                  {item.desc}
                </p>
              </div>

              <div className="pt-4 border-t border-white/10 flex items-center justify-between">
                <p className="text-[#d6e4f9] text-xs font-bold">{item.price}</p>
                <span className="material-symbols-outlined text-white/50 group-hover:text-white group-hover:translate-x-1 transition-all text-sm">
                  arrow_forward
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Dynamic Tag Cloud */}
        <div className="mt-16 text-center">
          <p className="text-xs uppercase tracking-wider text-white/50 mb-4 font-semibold">
            Comprehensive Suite Tags
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            {TAG_CLOUD.map((tag, idx) => (
              <span
                key={idx}
                onClick={() => setSearchQuery(tag)}
                className="px-4 py-2 bg-white/5 border border-white/10 rounded-full text-xs text-white/80 hover:border-[#8234c6] hover:bg-[#8234c6]/20 transition-all cursor-pointer"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
