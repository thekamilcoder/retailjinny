"use client";

import React, { useState } from "react";
import { motion } from "framer-motion";

interface WhyChooseUsProps {
  onOpenQuoteModal: (service?: string) => void;
}

export function WhyChooseUs({ onOpenQuoteModal }: WhyChooseUsProps) {
  const [email, setEmail] = useState("");
  const [isSent, setIsSent] = useState(false);

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setIsSent(true);
      setTimeout(() => {
        onOpenQuoteModal("Express Campaign Consultation");
      }, 1200);
    }
  };

  const REASONS = [
    { icon: "star", title: "Premium Quality", color: "text-[#8234c6]" },
    { icon: "bolt", title: "24hr Express Delivery", color: "text-[#f8be00]" },
    { icon: "savings", title: "Save Up To 40%", color: "text-green-500" },
    { icon: "support_agent", title: "Free Design Support", color: "text-blue-500" },
    { icon: "verified", title: "Expert Marketing Team", color: "text-[#000000]" },
    { icon: "thumb_up", title: "100% Satisfaction", color: "text-[#8234c6]" },
  ];

  return (
    <section id="about" className="px-5 md:px-16 py-20 bg-white">
      <div className="max-w-[1200px] mx-auto">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          {/* Left Column: Reasons */}
          <div className="lg:w-1/2">
            <span className="text-xs uppercase tracking-widest font-semibold text-[#8234c6] mb-3 block">
              THE RETAILJINNY ADVANTAGE
            </span>
            <h2 className="font-headline text-3xl md:text-5xl font-extrabold text-[#000000] mb-8">
              Why Choose Us
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {REASONS.map((item, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: idx * 0.08 }}
                  className="flex items-center gap-4 p-4 rounded-xl bg-[#f8f9fa] border border-[#e7e8e9] hover:shadow-sm transition-all"
                >
                  <span
                    className={`material-symbols-outlined ${item.color} text-3xl`}
                    style={{ fontVariationSettings: "'FILL' 1" }}
                  >
                    {item.icon}
                  </span>
                  <span className="font-headline text-base font-bold text-[#000000]">
                    {item.title}
                  </span>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Right Column: Lead Form Card */}
          <div className="lg:w-1/2 w-full">
            <div className="bg-[#e7e8e9]/60 p-8 md:p-10 rounded-3xl border border-[#c4c6cc] shadow-xl relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-[#8234c6]/10 rounded-full blur-2xl pointer-events-none" />

              <span className="text-xs font-bold uppercase tracking-wider text-[#8234c6] mb-2 block">
                EXPRESS DISPATCH
              </span>
              <h3 className="font-headline text-2xl md:text-3xl font-bold text-[#000000] mb-4">
                Need a campaign this week?
              </h3>
              <p className="text-[#44474c] text-sm md:text-base mb-8 leading-relaxed">
                Get in touch with our marketing experts for express 24-hour turnaround and dedicated account manager support.
              </p>

              {isSent ? (
                <div className="p-4 bg-green-50 border border-green-200 text-green-800 rounded-xl text-sm font-semibold flex items-center gap-2">
                  <span className="material-symbols-outlined text-green-600">check_circle</span>
                  Thank you! Redirecting to custom quote details...
                </div>
              ) : (
                <form onSubmit={handleEmailSubmit} className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Your Email Address"
                    className="flex-grow px-5 py-4 rounded-xl border border-[#74777d]/40 focus:ring-2 focus:ring-[#8234c6] focus:border-[#8234c6] outline-none text-sm bg-white"
                  />
                  <button
                    type="submit"
                    className="px-8 py-4 bg-[#000000] text-white rounded-xl font-semibold text-sm whitespace-nowrap hover:scale-105 active:scale-95 transition-all shadow-md cursor-pointer"
                  >
                    Get Quote Fast
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
